let
    Source = PostgreSQL.Database("127.0.0.1:15432", "komtas_rm1", [CreateNavigationProperties=false]),
    FactSales = Source{[Schema="dwh",Item="fact_sales"]}[Data]
in
    FactSales
