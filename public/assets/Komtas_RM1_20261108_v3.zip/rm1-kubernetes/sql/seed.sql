\getenv bi_password PBI_PASSWORD
BEGIN;
CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS dwh;
CREATE TABLE IF NOT EXISTS dwh.dim_date (
    date_key date PRIMARY KEY,
    year_number integer NOT NULL,
    month_number integer NOT NULL,
    month_start date NOT NULL
);
CREATE TABLE IF NOT EXISTS dwh.dim_product (
    product_key integer PRIMARY KEY,
    product_name text NOT NULL,
    category text NOT NULL,
    liters_per_unit numeric(8,3) NOT NULL CHECK (liters_per_unit > 0)
);
CREATE TABLE IF NOT EXISTS dwh.dim_outlet (
    outlet_key integer PRIMARY KEY,
    outlet_name text NOT NULL,
    country text NOT NULL,
    channel text NOT NULL,
    distributor_key integer NOT NULL,
    distributor_name text NOT NULL
);
CREATE TABLE IF NOT EXISTS dwh.dim_promotion (
    promotion_key integer PRIMARY KEY,
    promotion_name text NOT NULL
);
INSERT INTO dwh.dim_date
SELECT d::date, 2025, extract(month FROM d)::integer, date_trunc('month',d)::date
FROM generate_series(timestamp '2025-01-01',timestamp '2025-02-28',interval '1 day') d
ON CONFLICT DO NOTHING;
INSERT INTO dwh.dim_product VALUES
(1,'Sparkling Water 1L','Water',1.000),
(2,'Juice 500ml','Juice',0.500),
(3,'Soft Drink 330ml','Soft Drink',0.330)
ON CONFLICT DO NOTHING;
INSERT INTO dwh.dim_outlet
SELECT n, 'Outlet '||n,
       CASE WHEN n <= 6 THEN 'TR' ELSE 'DE' END,
       (ARRAY['HoReCa','Retail','Online'])[1+(n-1)%3],
       1+(n-1)/3, 'Distributor '||(1+(n-1)/3)
FROM generate_series(1,12) n
ON CONFLICT DO NOTHING;
INSERT INTO dwh.dim_promotion VALUES
(0,'No promotion'),(1,'HoReCa 10 percent'),(2,'Retail 5 percent')
ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS raw.sales_line (
    sales_line_key bigint PRIMARY KEY,
    sale_date date NOT NULL,
    outlet_key integer NOT NULL,
    product_key integer NOT NULL,
    promotion_key integer NOT NULL,
    sold_units integer NOT NULL CHECK (sold_units > 0),
    returned_units integer NOT NULL CHECK (returned_units BETWEEN 0 AND sold_units),
    unit_price_eur numeric(12,2) NOT NULL,
    discount_rate numeric(5,4) NOT NULL,
    source_reference text NOT NULL
);
INSERT INTO raw.sales_line
SELECT ((d.date_key-date '2025-01-01')*1000+o.outlet_key*10+p.product_key)::bigint,
       d.date_key,o.outlet_key,p.product_key,
       CASE o.channel WHEN 'HoReCa' THEN 1 WHEN 'Retail' THEN 2 ELSE 0 END,
       CASE WHEN o.channel='HoReCa' AND d.month_number=2 THEN 6 ELSE 10 END,
       CASE WHEN o.channel='HoReCa' THEN CASE WHEN d.month_number=2 THEN 2 ELSE 1 END ELSE 0 END,
       (p.product_key+1)::numeric,
       CASE o.channel WHEN 'HoReCa' THEN 0.10 WHEN 'Retail' THEN 0.05 ELSE 0 END,
       'SYNTH-RM1-'||d.date_key||'-'||o.outlet_key||'-'||p.product_key
FROM dwh.dim_date d CROSS JOIN dwh.dim_outlet o CROSS JOIN dwh.dim_product p
WHERE extract(day FROM d.date_key)<=28
ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS dwh.fact_sales (
    sales_line_key bigint PRIMARY KEY,
    date_key date NOT NULL REFERENCES dwh.dim_date,
    outlet_key integer NOT NULL REFERENCES dwh.dim_outlet,
    product_key integer NOT NULL REFERENCES dwh.dim_product,
    promotion_key integer NOT NULL REFERENCES dwh.dim_promotion,
    sold_units integer NOT NULL,
    returned_units integer NOT NULL,
    gross_revenue_eur numeric(14,2) NOT NULL,
    discount_amount_eur numeric(14,2) NOT NULL,
    return_amount_eur numeric(14,2) NOT NULL,
    net_volume_liters numeric(14,3) NOT NULL,
    source_reference text NOT NULL
);
INSERT INTO dwh.fact_sales
SELECT s.sales_line_key,s.sale_date,s.outlet_key,s.product_key,s.promotion_key,
       s.sold_units,s.returned_units,
       s.sold_units*s.unit_price_eur,
       s.sold_units*s.unit_price_eur*s.discount_rate,
       s.returned_units*s.unit_price_eur*(1-s.discount_rate),
       (s.sold_units-s.returned_units)*p.liters_per_unit,
       s.source_reference
FROM raw.sales_line s JOIN dwh.dim_product p USING(product_key)
ON CONFLICT(sales_line_key) DO UPDATE SET
    sold_units=excluded.sold_units,
    returned_units=excluded.returned_units,
    gross_revenue_eur=excluded.gross_revenue_eur,
    discount_amount_eur=excluded.discount_amount_eur,
    return_amount_eur=excluded.return_amount_eur,
    net_volume_liters=excluded.net_volume_liters;
CREATE OR REPLACE VIEW dwh.v_sales_detail AS
SELECT f.*,d.month_start,o.country,o.channel,o.distributor_key,o.distributor_name,o.outlet_name,
       p.product_name,p.category,r.promotion_name
FROM dwh.fact_sales f
JOIN dwh.dim_date d USING(date_key)
JOIN dwh.dim_outlet o USING(outlet_key)
JOIN dwh.dim_product p USING(product_key)
JOIN dwh.dim_promotion r USING(promotion_key);
SELECT format('CREATE ROLE rm1_bi LOGIN PASSWORD %L', :'bi_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='rm1_bi')
\gexec
SELECT format('ALTER ROLE rm1_bi PASSWORD %L', :'bi_password')
\gexec
ALTER ROLE rm1_bi SET default_transaction_read_only=on;
REVOKE ALL ON SCHEMA public FROM rm1_bi;
GRANT CONNECT ON DATABASE komtas_rm1 TO rm1_bi;
GRANT USAGE ON SCHEMA dwh TO rm1_bi;
GRANT SELECT ON ALL TABLES IN SCHEMA dwh TO rm1_bi;
ALTER DEFAULT PRIVILEGES IN SCHEMA dwh GRANT SELECT ON TABLES TO rm1_bi;
COMMIT;
SELECT 'RM1 seed complete' AS status,count(*) AS fact_rows FROM dwh.fact_sales;
