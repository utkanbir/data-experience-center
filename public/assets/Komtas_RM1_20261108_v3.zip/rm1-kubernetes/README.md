# Windows ve Linux hızlı başlangıç

ZIP’i çıkarın ve rm1-kubernetes klasöründe terminal açın.
Windows: `.\Deploy.ps1`, başarılı olunca `.\Run-Scenario.ps1`.
Linux: `bash deploy.sh`, başarılı olunca `bash run-scenario.sh`.
Ön koşullar ve bağlantı adımları için KURULUM.md, iş sorguları için DENEY.md.

# Referans Mimari 1 — PostgreSQL veri ambarı + Power BI

Docker Desktop Kubernetes üzerinde tek PostgreSQL instance'ı, kalıcı disk, sentetik veri yükleme Job'u ve SQL doğrulama Job'u. Power BI Desktop Windows'ta kalır. dbt, Cube, OpenMetadata, Informatica, Trino, Neo4j ve agent bu ilk mimariye dahil değildir.

## Çalıştırma

Docker Desktop açık, Linux containers ve Kubernetes etkin olmalı. `kubectl config get-contexts` çıktısında `docker-desktop` görünmeli. Image indirme için Docker Hub erişimi gerekir. PostgreSQL için 2 GiB disk, 1 GiB RAM limiti tanımlandı; Kubernetes'in kendi kaynakları ayrıca gerekir. Varsayılan StorageClass kontrol edilir, başka cluster'a veya context'e otomatik geçilmez.

PowerShell'i bu klasörde aç:

```powershell
.\Deploy.ps1
.\Connect.ps1
```

`Connect.ps1` terminali açık kalırken ikinci bir terminalde:

```powershell
.\Get-Connection.ps1
```

Power BI'da PostgreSQL sunucu `127.0.0.1:15432`, database `komtas_rm1`, kullanıcı `rm1_bi`. Her kurulumun parolası rastgele üretilir; pakette parola bulunmaz. `Get-Connection.ps1` yalnız BI bağlantı parolasını gösterir. Power BI modeli için [powerbi/README.md](powerbi/README.md) adımlarını uygula.

Yerel yürütme ilkesi PS1 çalıştırmayı engellerse yalnız bu oturum için `Set-ExecutionPolicy -Scope Process Bypass` kullanılabilir. Kurumsal makinede kurum politikasını izle; yönetici yetkisi bu lab için varsayılan gereksinim değildir.

## Çalışma düzeni

| Bileşen | Çalışma yeri | Görev |
| --- | --- | --- |
| PostgreSQL 17.11, tek StatefulSet replica | Kubernetes | `raw` ve `dwh` şemaları aynı DB'de |
| 2 GiB PVC | Docker Desktop StorageClass | Pod yeniden başlarken veri korunur |
| rm1-seed Job | Kubernetes, PostgreSQL client image | SQL modeli ve tekrar çalıştırılabilir sentetik veri |
| rm1-verify Job | Kubernetes, BI kullanıcısı | Referans hesap ve salt okuma yetkisi kontrolü |
| Power BI Desktop | Windows | Yıldız model, DAX ölçüleri ve dashboard |
| Port-forward | Yerel PowerShell | Yalnız 127.0.0.1:15432 üzerinden DB erişimi |

`Deploy.ps1` namespace ve configmap'i uygular, Secret yoksa oluşturur, PostgreSQL'i bekler, seed ve verify işlerini sırayla çalıştırır. Yalnız aynı adlı önceki Job nesnelerini yeniden oluşturur. PVC'yi silmez. Var olan Secret tekrar kullanılır. PostgreSQL ilk oluşturulurken Secret parolası DB'ye yazılır; çalışan DB'nin Secret'ını elle değiştirmek DB parolasını değiştirmez. PVC var ama Secret yoksa script otomatik yeni şifre üretmez.

Kubernetes container image'larını çalıştırır. Pod içine Docker motoru kurulmaz. Aynı fiziksel DB içinde kaynak ve veri ambarı şemaları bulunur; bu mimari iki bağımsız kaynak veya federasyon değildir.

## Demo verisi ve beklenen sonuç

İki ülke (TR/DE), üç kanal (HoReCa/Retail/Online), dört distribütör, 12 outlet, üç ürün. Ocak ve Şubat 2025'in ilk 28'er gününde 2.016 satış satırı. Kesintisiz takvim 59 gündür. Bütün tutarlar karşılaştırılabilir sentetik EUR'dur; ülke bazlı kur dönüşümü bu veriye eklenmedi.

Brüt gelir = satılan adet × birim fiyat. İskonto satılan miktara uygulanır. İade tutarı iade edilen adet × iskontolu birim fiyattır; indirim ikinci kez düşülmez. Net Revenue = brüt − iskonto − iade. Net hacim litre = (satılan adet − iade adet) × ambalaj litresi. Average Price = Net Revenue / net litre. İadeler aynı satış satırına ve aynı aya bağlandı; ayrı iade tarihi/finansal dönem politikası kapsam dışı.

| Kanal | Ocak Net Revenue EUR | Şubat Net Revenue EUR | Değişim |
| --- | ---: | ---: | ---: |
| HoReCa | 8.164,80 | 3.628,80 | -%55,56 |
| Retail | 9.576,00 | 9.576,00 | %0 |
| Online | 10.080,00 | 10.080,00 | %0 |
| Toplam | 27.820,80 | 23.284,80 | -%16,30 |

`expected-results.csv` ay/kanal bazında gelir, hacim, ortalama fiyat ve aktif outlet referanslarını içerir. HoReCa düşüşünü göstermek için satılan adet 10'dan 6'ya, iade adet 1'den 2'ye değiştirildi. Diğer kanallar ve liste fiyatları sabit kaldı. Bu verilerle nedensellik iddiası kurulmaz.

SQL doğrulaması bağımsız sabit beklenen toplamlarla karşılaştırır. Ortak metric API kurulmadı; SQL hesabı test oracle'ıdır, ürünleşmiş semantic katman değildir. Ana tüketimde metrikler Power BI DAX'ta tanımlanır. `rm1_bi` sadece dwh şemasını okur. SQL testlerinin varlığı yönetilen kalite/contract/ihlal süreci kazandırmaz; sunumun kapsam notu bu yüzden otomatik yükseltilmez.

## Tekrar çalıştırma ve teşhis

```powershell
.\Verify.ps1
kubectl --context docker-desktop -n komtas-rm1 get pods,svc,pvc,jobs
kubectl --context docker-desktop -n komtas-rm1 logs postgres-0
kubectl --context docker-desktop -n komtas-rm1 logs job/rm1-seed
kubectl --context docker-desktop -n komtas-rm1 logs job/rm1-verify
kubectl --context docker-desktop -n komtas-rm1 get events --sort-by=.lastTimestamp
```

PVC Pending ise `kubectl --context docker-desktop get storageclass` ile varsayılan provisioner'ı kontrol et. ImagePullBackOff varsa image indirme/ağ erişimini kontrol et. Port doluysa `.\Connect.ps1 -Port 15433` ve `.\Get-Connection.ps1 -Port 15433` kullan; Power BI sunucusundaki portu da değiştir. Pod yeniden başlarsa port-forward'ı yeniden çalıştır.

Veriyi silmeden durdurmak için `Stop.ps1`, tekrar başlatmak için `Deploy.ps1`. Namespace/PVC silme komutu pakete eklenmedi. Docker Desktop cluster reset'i veya disk temizliği PVC verisini kaybettirebilir; bu düzen tek makine eğitim lab'ıdır, yedekli üretim kurulumu değildir.

## Hazırlık ve doğrulama durumu

Bu paketi hazırlayan oturumda Docker motoruna ve Kubernetes API'sine erişim izinleri engellendi. Bu nedenle bu cluster üzerinde kurulum yapıldığı iddia edilmez. Dosyaların çevrimdışı kontrol sonuçları `VALIDATION.md` içinde. Küme üzerinde `Deploy.ps1` ve sonrasında Power BI sonuç karşılaştırması tamamlanınca uçtan uca doğrulama yapılmış olur.

## Kaynaklar

- https://hub.docker.com/_/postgres
- https://www.postgresql.org/docs/17/release-17-11.html
- https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/
- https://kubernetes.io/docs/tasks/access-application-cluster/port-forward-access-application-cluster/
- https://learn.microsoft.com/en-us/power-query/connectors/postgresql

## Ortamı durdurma ve tamamen kaldırma

Veriyi koruyarak durdur: Windows `.\Stop.ps1`, Linux `bash stop.sh`.
Tamamen kaldır: Windows `.\Remove-Environment.ps1`, Linux `bash remove-environment.sh`.
Silme namespace içindeki tüm kaynakları, PVC ve parolaları kaldırır. Önce yedek alın. Script context ve kaynakları gösterir, lab sahiplik etiketini kontrol eder ve namespace adını yazarak onay ister. Farklı cevap iptal eder. Fiziksel veri temizliği StorageClass reclaim politikasına bağlıdır. Tekrar Deploy ile kurulabilir. Yerel reports klasöründeki raporlar ayrıca yönetilir.
