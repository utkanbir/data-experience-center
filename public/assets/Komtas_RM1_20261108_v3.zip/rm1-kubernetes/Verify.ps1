[CmdletBinding()]
param()
. (Join-Path $PSScriptRoot 'Common.ps1')
Start-Rm1Job -Name 'rm1-verify' -Manifest (Join-Path $PSScriptRoot 'k8s/verify-job.yaml')
