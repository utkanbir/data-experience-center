[CmdletBinding()]
param([ValidateRange(1024,65535)][int]$Port = 15432)
. (Join-Path $PSScriptRoot 'Common.ps1')
$taskSecret = (Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'get', 'secret', 'rm1-credentials', '-o', 'json') | Out-String) | ConvertFrom-Json
$taskPassword = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($taskSecret.data.'bi-password'))
[pscustomobject]@{ Server = "127.0.0.1:$Port"; Database = 'komtas_rm1'; Username = 'rm1_bi'; Password = $taskPassword } | Format-List
