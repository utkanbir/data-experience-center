set -euo pipefail
RM1_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RM1_NAMESPACE='komtas-rm1'
RM1_CONTEXT='docker-desktop'
k() { kubectl --context "$RM1_CONTEXT" "$@"; }
run_job() {
  local name="$1" manifest="$2"
  k -n "$RM1_NAMESPACE" delete job "$name" --ignore-not-found=true --wait=true
  k apply -f "$manifest"
  if ! k -n "$RM1_NAMESPACE" wait --for=condition=complete "job/$name" --timeout=330s; then
    k -n "$RM1_NAMESPACE" logs "job/$name" --all-containers=true || true
    k -n "$RM1_NAMESPACE" describe job "$name" || true
    return 1
  fi
  k -n "$RM1_NAMESPACE" logs "job/$name"
}
