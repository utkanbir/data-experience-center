# RM1 kurulumu: Windows ve Linux

ZIP'i çıkarın. Terminali ZIP içindeki rm1-kubernetes klasöründe açın.
Docker Desktop Linux containers ve Kubernetes açık, kubectl kurulu olmalı. docker-desktop context'i ve varsayılan StorageClass gerekli. Linux için Bash, OpenSSL ve base64 de gerekli. Yalnız Docker Engine kurmak Kubernetes sağlamaz. Bu profil başka cluster türleri için doğrulanmadı.

## Windows PowerShell

```powershell
.\Deploy.ps1
.\Run-Scenario.ps1
```

İlk komut PostgreSQL, kalıcı disk, yerel rastgele parolalar ve sentetik veriyi hazırlar; kontrolleri çalıştırır. Başarıyla bittikten sonra ikinci komut iş sorgularını ve doğrulamayı çalıştırır. Yalnız Run-Scenario.ps1 kurulum yapmaz. Windows script çalıştırma ilkesi engellerse kurumunuzun onaylı PowerShell çalıştırma yöntemini kullanın.

## Linux Bash

```bash
bash deploy.sh
bash run-scenario.sh
```

Scriptleri bash ile çağırdığınız için chmod gerekmez. Aynı Kubernetes manifestleri ve SQL dosyaları kullanılır. Secret mevcutsa tekrar kullanılır; PVC var ancak Secret kayıpsa kurulum durur. Scripti bash -x ile çalıştırmayın; parola üretimini izleme çıktısına yazdırabilir.

## İstemciden bağlanma: isteğe bağlı

Bir terminalde Windows: `.\Connect.ps1`; Linux: `bash connect.sh`. Tünel açık kalsın.
Diğer terminalde Windows: `.\Get-Connection.ps1`; Linux: `bash get-connection.sh`. Bu komut parolayı yalnız yerel terminalde gösterir.
Seçilen yerel portu kullanın (varsayılan 15432). Veritabanı komtas_rm1, kullanıcı rm1_bi.

Power BI Desktop Windows'ta ayrıca kurulur. Linux'ta SQL istemcisi veya deney scripti kullanılır. PBIX dahil değildir. DENEY.md sorguları, formülleri ve beklenen sonuçları açıklar.

## Tekrar kontrol ve durdurma

Windows: `.\Verify.ps1`, `.\Stop.ps1`.
Linux: `bash verify.sh`, `bash stop.sh`.
Durdurma veriyi ve Secret'ı korur. Tekrar Deploy komutuyla başlatın.

Hedef Kubernetes üzerinde iki platform için uçtan uca doğrulama henüz yapılmadı.

## Windows: Not digitally signed / UnauthorizedAccess

İndirme engeli varsa ZIP’i çıkardığınız rm1-kubernetes klasöründe şu komutları çalıştırın:

```powershell
Get-ChildItem -LiteralPath . -Filter '*.ps1' -File | Unblock-File
.\Deploy.ps1
```

Yönetici yetkisi gerekmez; yönetici terminali açmak tek başına imza engelini çözmez. Komut yalnız bu klasördeki PowerShell dosyalarını unblock eder, execution policy ayarını değiştirmez. Hata sürerse `Get-ExecutionPolicy -List` çıktısını kontrol edin. AllSigned veya kurum politikası varsa Unblock-File yeterli olmayabilir; onaylı imzalı script gerekir.

## Deney raporu

Run-Scenario.ps1 / run-scenario.sh her çalıştırmada yeni reports/run-… klasörü oluşturur. rapor.html dosyasını tarayıcıda açın; internet veya ek runtime gerekmez. Tasarım kapsam notu ile deney kontrol sonuçları ayrıdır. Katman kartları doğrulanan, kısmi, kapsam dışı ve denenmeyen ihtiyaçları gösterir. sonuc.json dosyasını web uygulamasında Ortak iş senaryosu veya RM1 Senaryo & deney bölümünden yükleyin. kanitlar klasörü sorgu dosyalarını ve çıktıları içerir. Sorgu başarısız olsa bile rapor üretilir; veritabanına ulaşılamazsa kontroller denenmedi olarak gösterilir. Import edilen rapor yerel beyan niteliğindedir, dijital imzalı değildir. Raporları Git deposuna eklemeyin.

## Ortamı durdurma ve tamamen kaldırma

Veriyi koruyarak durdur: Windows `.\Stop.ps1`, Linux `bash stop.sh`.
Tamamen kaldır: Windows `.\Remove-Environment.ps1`, Linux `bash remove-environment.sh`.
Silme namespace içindeki tüm kaynakları, PVC ve parolaları kaldırır. Önce yedek alın. Script context ve kaynakları gösterir, lab sahiplik etiketini kontrol eder ve namespace adını yazarak onay ister. Farklı cevap iptal eder. Fiziksel veri temizliği StorageClass reclaim politikasına bağlıdır. Tekrar Deploy ile kurulabilir. Yerel reports klasöründeki raporlar ayrıca yönetilir.
