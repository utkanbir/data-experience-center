[CmdletBinding()]
param()
. (Join-Path $PSScriptRoot 'Common.ps1')
if (-not (Get-Command kubectl -ErrorAction SilentlyContinue)) { throw 'kubectl bulunamadi. Docker Desktop kurulumu ve PATH kontrol edilmeli.' }
Invoke-Rm1Kubectl -Arguments @('get', 'nodes', '--request-timeout=10s') | Out-Host
$taskClasses = (Invoke-Rm1Kubectl -Arguments @('get', 'storageclass', '-o', 'json') | Out-String) | ConvertFrom-Json
$taskDefault = @($taskClasses.items | Where-Object { $_.metadata.annotations.'storageclass.kubernetes.io/is-default-class' -eq 'true' -or $_.metadata.annotations.'storageclass.beta.kubernetes.io/is-default-class' -eq 'true' })
if ($taskDefault.Count -eq 0) { throw 'Varsayilan StorageClass bulunamadi. Docker Desktop Kubernetes depolamasi hazir olmali.' }
Invoke-Rm1Kubectl -Arguments @('apply', '-f', (Join-Path $PSScriptRoot 'k8s/namespace.yaml')) | Out-Host
$taskExistingSecret = (Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'get', 'secret', 'rm1-credentials', '--ignore-not-found=true', '-o', 'name') | Out-String).Trim()
if (-not $taskExistingSecret) {
    $taskPod = (Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'get', 'pvc', 'data-postgres-0', '--ignore-not-found=true', '-o', 'name') | Out-String).Trim()
    if ($taskPod) { throw 'Mevcut PVC var ancak parola Secret kayip. Yeni parola uretmeden mevcut Secret yedegini geri yukleyin.' }
    Write-Rm1Object -Object @{
        apiVersion = 'v1'; kind = 'Secret'
        metadata = @{ name = 'rm1-credentials'; namespace = $Rm1Namespace }
        type = 'Opaque'
        stringData = @{ 'admin-password' = (New-Rm1Password); 'bi-password' = (New-Rm1Password) }
    }
}
$taskSql = @{}
foreach ($taskSqlFile in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'sql') -Filter '*.sql') {
    $taskSql[$taskSqlFile.Name] = [IO.File]::ReadAllText($taskSqlFile.FullName)
}
Write-Rm1Object -Object @{
    apiVersion = 'v1'; kind = 'ConfigMap'
    metadata = @{ name = 'rm1-sql'; namespace = $Rm1Namespace }
    data = $taskSql
}
Invoke-Rm1Kubectl -Arguments @('apply', '-f', (Join-Path $PSScriptRoot 'k8s/postgres.yaml')) | Out-Host
Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'rollout', 'status', 'statefulset/postgres', '--timeout=330s') | Out-Host
Start-Rm1Job -Name 'rm1-seed' -Manifest (Join-Path $PSScriptRoot 'k8s/seed-job.yaml')
Start-Rm1Job -Name 'rm1-verify' -Manifest (Join-Path $PSScriptRoot 'k8s/verify-job.yaml')
Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'get', 'pods,svc,pvc,jobs') | Out-Host
Write-Host 'Hazir. Power BI erisimi icin: .\Connect.ps1'
Write-Host 'Baglanti bilgisi icin ayri terminalde: .\Get-Connection.ps1'
