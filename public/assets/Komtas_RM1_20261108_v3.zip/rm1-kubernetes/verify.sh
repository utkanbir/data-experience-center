#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
run_job rm1-verify "$RM1_DIR/k8s/verify-job.yaml"
