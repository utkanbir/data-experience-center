$ErrorActionPreference = 'Stop'
$Rm1Namespace = 'komtas-rm1'
$Rm1Context = 'docker-desktop'

function Invoke-Rm1Kubectl {
    param([string[]]$Arguments)
    $taskResult = & kubectl --context $Rm1Context @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ($taskResult -join [Environment]::NewLine)
    }
    return $taskResult
}

function Write-Rm1Object {
    param($Object)
    $taskJson = $Object | ConvertTo-Json -Depth 30 -Compress
    $taskResult = $taskJson | & kubectl --context $Rm1Context apply -f - 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ($taskResult -join [Environment]::NewLine)
    }
    $taskResult | ForEach-Object { Write-Host $_ }
}

function New-Rm1Password {
    $taskBytes = New-Object byte[] 24
    $taskGenerator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $taskGenerator.GetBytes($taskBytes) } finally { $taskGenerator.Dispose() }
    return ([BitConverter]::ToString($taskBytes)).Replace('-', '').ToLowerInvariant()
}

function Start-Rm1Job {
    param([string]$Name, [string]$Manifest)
    Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'delete', 'job', $Name, '--ignore-not-found=true', '--wait=true') | Out-Host
    Invoke-Rm1Kubectl -Arguments @('apply', '-f', $Manifest) | Out-Host
    try {
        Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'wait', '--for=condition=complete', "job/$Name", '--timeout=330s') | Out-Host
    } catch {
        & kubectl --context $Rm1Context -n $Rm1Namespace logs "job/$Name" --all-containers=true
        & kubectl --context $Rm1Context -n $Rm1Namespace describe job $Name
        throw
    }
    Invoke-Rm1Kubectl -Arguments @('-n', $Rm1Namespace, 'logs', "job/$Name") | Out-Host
}
