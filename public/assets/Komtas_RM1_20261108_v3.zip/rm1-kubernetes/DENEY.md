# Ortak iş senaryosu: İçecek dağıtımı

İki ülkede, üç satış kanalıyla çalışan şirket HoReCa net gelir düşüşünü incelemek, hacim ve ortalama fiyat etkisini ayırmak, metrik tanımı ve veri kaynağını doğrulamak istiyor.

Linux karşılıkları: önce `bash deploy.sh`, sonra `bash run-scenario.sh`. Ayrıntılar KURULUM.md.

## Çalıştır

1. Docker Desktop Kubernetes açıkken `./Deploy.ps1` çalıştır. Sentetik veri yüklenir ve referans kontrolleri yapılır.
2. `./Run-Scenario.ps1` çalıştır. Yerel psql veya port-forward gerektirmez; pod içindeki istemciyle yerel yönetici bağlantısında SET ROLE ile salt okuma BI rolüne geçerek sorgular.
3. SQL dosyalarını tek tek incele veya kendi PostgreSQL istemcinde çalıştır. İstemci bağlantısı için bir terminalde `./Connect.ps1`, diğerinde `./Get-Connection.ps1` çalıştır. Power BI Desktop ayrıca kurulmalı; bu paket PBIX üretmez.

## Sorgular ve beklenen sonuç

- `sql/01-kanal-geliri.sql`: ülke ve kanal bazında aylık net gelir, litre ve ağırlıklı ortalama fiyat.
- `sql/02-horeca-degisim.sql`: HoReCa Ocak 8.164,80 EUR, Şubat 3.628,80 EUR; fark −4.536,00 EUR (%−55,56). Net litre 1.844,64 → 819,84. Ortalama fiyat yaklaşık 4,426230 EUR/litre. Hacim etkisi −4.536,00 EUR, fiyat etkisi 0,00 EUR. Ayrıştırma sırası: önce hacim eski fiyatla, sonra fiyat yeni hacimle.
- `sql/03-distributor-urun.sql`: ülke, distribütör ve ürün bazında düşüşün dağılımı.
- `sql/verify.sql`: 2.016 satır, referans gelir/hacim toplamları ve BI salt okuma yetkisi; hata halinde işlem başarısız olur.

Net gelir = brüt − iskonto − iade. İade iskontolu fiyattan hesaplanır. Ortalama fiyat toplam gelir / toplam net litredir. Veri sentetik EUR; kur dönüşümü yok. İadeler satışla aynı dönemdedir.

## RM1 ile öğrendiklerimiz

SQL raporlaması ve hesap doğrulaması uygulanır. Tek PostgreSQL içinde raw ve dwh şemaları vardır. Ortak executable metrik servisi, merkezi owner/onay/lineage, federasyon, data product yaşam döngüsü, ontology, knowledge graph ve kanıtlı AI bu pakette yoktur. Kontroller merkezi kalite yönetimi anlamına gelmez. Promosyon ilişkisi ticari nedensellik kanıtı değildir.

Kullanıcı rm1_bi önceden tanımlıdır; parolalar Deploy.ps1 tarafından yerelde oluşturulur. Parolayı rapora veya Git deposuna ekleme. Hedef Kubernetes ve Power BI uçtan uca doğrulaması henüz yapılmadı.

## Deney raporu

Run-Scenario.ps1 / run-scenario.sh her çalıştırmada yeni reports/run-… klasörü oluşturur. rapor.html dosyasını tarayıcıda açın; internet veya ek runtime gerekmez. Tasarım kapsam notu ile deney kontrol sonuçları ayrıdır. Katman kartları doğrulanan, kısmi, kapsam dışı ve denenmeyen ihtiyaçları gösterir. sonuc.json dosyasını web uygulamasında Ortak iş senaryosu veya RM1 Senaryo & deney bölümünden yükleyin. kanitlar klasörü sorgu dosyalarını ve çıktıları içerir. Sorgu başarısız olsa bile rapor üretilir; veritabanına ulaşılamazsa kontroller denenmedi olarak gösterilir. Import edilen rapor yerel beyan niteliğindedir, dijital imzalı değildir. Raporları Git deposuna eklemeyin.
