# Doğrulama durumu

Hazırlama tarihi: 8 Kasım 2026.

## Tamamlanan kontroller

- Yedi PowerShell dosyası PowerShell parser ile sözdizimi hatası olmadan okundu.
- Altı Kubernetes nesnesi YAML parser ile okundu. Namespace, StatefulSet, iki Service ve iki Job arasındaki selector, PVC, SQL mount ve Secret referansları kontrol edildi.
- `seed.sql`, PostgreSQL WASM test motorunda (PGlite 0.5.15) iki kez çalıştırıldı. İkinci yüklemede 2.016 fact satırı korundu, satır çoğalmadı.
- Ocak ve Şubat gelir toplamları, HoReCa gelirleri ve Şubat HoReCa hacmi `verify.sql` içindeki sabit beklenen değerlerle eşleşti.
- Altı ay/kanal grubunun gelir ve hacimleri ayrıca bağımsız aritmetik hesapla karşılaştırıldı. Her kanalda dört aktif outlet bulundu.
- BI rolüyle veri okuma başarılı, yazma denemesi reddedildi.
- Bir fact satırına kasıtlı +1 EUR fark eklenince referans kontrolü hatayı yakaladı.

SQL testi sırasında yalnız psql'a ait `\getenv`/`\gexec` komutları eşdeğer test SQL'iyle değiştirildi ve test motorunun DB adı kullanıldı. Paketteki psql komutları Kubernetes Job'larında PostgreSQL client ile çalışacak. Test motoru Docker image'ının, psql istemcisinin veya Kubernetes servis ağının yerine geçmez.

## Henüz tamamlanmayan kontroller

- Docker Desktop motoruna bu oturumdan erişim izin nedeniyle engellendi.
- `docker-desktop` kube context'i mevcut, fakat yerel Kubernetes API bağlantısı bu oturumdan izin nedeniyle engellendi.
- Image pull, PVC provision, StatefulSet/Job çalışması ve port-forward bu cluster'da doğrulanmadı. YAML kontrolleri Kubernetes API server dry-run yerine geçmez.
- Power BI Desktop kurulumu, gerçek bağlantı, DAX hesaplaması ve rapor görüntüsü doğrulanmadı. PBIX dosyası hazırlanmadı; model ve ölçü talimatları verildi.

`Deploy.ps1` çalıştırıldığında seed ve verify Job'ları sırasıyla tamamlanmalı. Ardından Power BI matrix sonucu `expected-results.csv` ile karşılaştırılmalı. SQL testinin geçmesi Power BI DAX modelinin de doğru kurulduğunu kanıtlamaz.
