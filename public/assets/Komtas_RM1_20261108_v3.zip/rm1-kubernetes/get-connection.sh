#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
printf '%s\n' 'Server: 127.0.0.1:15432' 'Database: komtas_rm1' 'Username: rm1_bi'
printf 'Password: '
k -n "$RM1_NAMESPACE" get secret rm1-credentials -o 'jsonpath={.data.bi-password}' | base64 --decode
printf '\n'
